USE CSD430;

INSERT INTO garrett_movies_data (title, director, genre, release_year, score) VALUES
('Oppenheimer', 'Christopher Nolan', 'Biography/Drama', 2023, 8.2),
('The Truman Show', 'Peter Weir', 'Comedy/Drama', 1998, 8.2),
('Parasite', 'Bong Joon-ho', 'Thriller/Drama', 2019, 8.5),
('Spider-Man: Across the Spider-Verse', 'Joaquim Dos Santos, Kemp Powers, Justing K. Thompson', 'Animated/Action', 2023, 8.5),
('12 Angry Men', 'Sidney Lumet', 'Crime/Drama', 1957, 9.0),
('Psycho', 'Alfred Hitchcock', 'Horror/Daram', 1960, 8.5),
('Top Gun: Maverick', 'Joseph Kosinski', 'Action/Drama', 2022, 8.2),
('The Wild Robot', 'Chris Sanders', 'Animation/Sci-Fi', 2024, 8.1),
('Tenet', 'Christopher Nolan', 'Action/Sci-Fi', 2020, 7.3),
('Palm Springs', 'Max Barbakow', 'Romatic Comedy', 2020, 7.4);