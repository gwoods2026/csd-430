USE CSD430;

DROP TABLE IF EXISTS garrett_movies_data;