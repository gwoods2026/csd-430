package com.csd430.beans;

import java.io.Serializable;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;


//Bean to connect and talk to the database
public class MovieBean implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private int movieID;
	private String title;
	private String director;
	private String genre;
	private int releaseYear;
	private double score;
	
	private final String dbUrl = "jdbc:mysql://localhost:3306/CSD430";
	private final String dbUser = "student1";
	private final String dbPass = "pass";
	
	public MovieBean() {}
	
	
	// Sets up getters and setters
	public int getMovieID() { return movieID; }
	public void setMovieId(int movieID) { this.movieID = movieID; }
	
	public String getTitle() { return title; }
	public void setTitle(String title) { this.title = title; }
	
	public String getDirector() { return director; }
	public void setDirector(String director) { this.director = director; }
	
	public String getGenre() { return genre; }
	public void setGenre(String genre) { this.genre = genre; }
	
	public int getReleaseYear() { return releaseYear; }
	public void setReleaseYear(int releaseYear) { this.releaseYear = releaseYear; }
	
	public double getScore() { return score; }
	public void setScore(double score) { this.score = score; }
	
	
	//gets data from SQL table
	public List<Integer> getAllMovieIds() {
		List<Integer> ids = new ArrayList<>();
		String query = "SELECT movie_ID FROM garrett_movies_data ORDER BY movie_id";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
					Statement stmt = conn.createStatement();
					ResultSet rs = stmt.executeQuery(query)) {
				while (rs.next()) {
					ids.add(rs.getInt("movie_id"));
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return ids;		
	}
	
	//gets data for specified movie
	public MovieBean getMovieById(int id) {
		MovieBean movie = null;
		String query = "SELECT * FROM garrett_movies_data WHERE movie_id = ?";
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			try (Connection conn = DriverManager.getConnection(dbUrl, dbUser, dbPass);
				PreparedStatement pstmt = conn.prepareStatement(query)) {
			  pstmt.setInt(1,  id);
			  try (ResultSet rs = pstmt.executeQuery()) {
				  if (rs.next( )) {
					  movie = new MovieBean();
					  movie.setMovieId(rs.getInt("movie_ID"));
					  movie.setTitle(rs.getString("title"));
					  movie.setDirector(rs.getString("director"));
					  movie.setGenre(rs.getString("genre"));
					  movie.setReleaseYear(rs.getInt("release_year"));
					  movie.setScore(rs.getDouble("score"));
				  }
			  }
			}
	} catch (Exception e) {
		e.printStackTrace();
	}
	return movie;
}
}