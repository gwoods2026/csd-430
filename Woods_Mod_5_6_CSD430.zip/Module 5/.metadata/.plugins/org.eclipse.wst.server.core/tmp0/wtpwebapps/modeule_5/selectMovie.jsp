<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List, com.csd430.beans.MovieBean" %>
<!DOCTYPE html>
<html>
<head>
	<title>Movie Lookup Tool</title>
	<style>
		table {border-collapse: collapse; width: 80%; margin-top: 20px;}
		th, td {border: 1px solid #333; padding: 8px; text-align: left;}
		th {background-color: #808080;}
	</style>
</head>
<body>
	<h1>Movie Lookup</h1>
	
	<%
		MovieBean bean = new MovieBean();
		List<Integer> idList = bean.getAllMovieIds();
		String selectedIdParam = request.getParameter("movieId");
	%>
	
	
	<!-- creates drop down and View Movie button -->
	<form method="post" action="selectMovie.jsp">
		<label for="movieID">Select a Movie ID:</label>
		<select name="movieId" id="movieId">
			<%
				for (Integer id : idList) {
					String selectedAttr = (selectedIdParam != null && selectedIdParam.equals(String.valueOf(id))) ? "selected" : "";
			%>
				<option value="<%= id %>" <%= selectedAttr %>><%= id %></option>
			<%
				}
			%>
		</select>
		<input type="submit" value="View Movie">
	</form>
	
	<%
		if (selectedIdParam != null && !selectedIdParam.isEmpty()) {
			int selectedId = Integer.parseInt(selectedIdParam);
			MovieBean selectedMovie = bean.getMovieById(selectedId);
			
			if (selectedMovie != null) {
	%>
	
		<!-- creates the table and populates data based off of choice. -->
		<h2>Selected Movie Details</h2>
		<table>
			<thead>
				<tr>
					<th>Movie ID (Primary Key)</th>
					<th>Movie Title</th>
					<th>Director</th>
					<th>Genre</th>
					<th>Release Year</th>
					<th>Score</th>
				</tr>
			</thead>
			<tbody>
				<tr>
					<td><%= selectedMovie.getMovieID() %></td>
					<td><%= selectedMovie.getTitle() %></td>
					<td><%= selectedMovie.getDirector() %></td>
					<td><%= selectedMovie.getGenre() %></td>
					<td><%= selectedMovie.getReleaseYear() %></td>
					<td><%= selectedMovie.getScore() %></td>
				</tr>
			</tbody>
		</table>
	<%
			}
		}
	%>
	
	<!-- link back to index -->
	<p><a href="index.jsp">Back to Index</a></p>
</body>
</html>