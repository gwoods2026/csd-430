<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<%@ page import="java.util.List, com.csd430.beans.MovieBean" %>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Add New Movie to Database</title>
<style>
	body {font-family: Arial, sans-serif; margin: 20px}
	.form-container {margin-bottom: 30px; padding: 15px; border: 1px solid #ccc; width: 400px;}
	.form-group {margin-bottom: 10px;}
	label {display: inline-block; width: 130px; font-weight: bold;}
	table {border-collapse: collapse; width: 90%; margin-top: 15px;}
	th, td {border: 1px solid #333; padding: 8px; text-align: left;}
	th {background-color: #808080; color: white}
</style>
</head>
<body>
	<h1>Add New Movie</h1>
	<p>You can fill out the form below to add a new movie to the database.</p>
	
	<%
		MovieBean bean = new MovieBean();
		String statusMessage = "";
		
		// Checks to see if the form was submitted via POST
		if ("POST".equalsIgnoreCase(request.getMethod())) {
			String title = request.getParameter("title");
			String director = request.getParameter("director");
			String genre = request.getParameter("genre");
			String releaseYearStr = request.getParameter("releaseYear");
			String scoreStr = request.getParameter("score");
			
			if (title != null && !title.trim().isEmpty()) {
				try {
					int release_Year = Integer.parseInt(releaseYearStr);
					double score = Double.parseDouble(scoreStr);
					
					boolean success = bean.addMovie(title, director, genre, release_Year, score);
					if (success) {
						statusMessage = "Success! '" + title + "' has been added.";
					} else {
						statusMessage = "Unable to add.";
					}
				} catch (NumberFormatException e) {
					statusMessage = "Please enter a valid number.";
				}
			}
		}
		
		// gets all recrods
		List<MovieBean> allMovies = bean.getAllMovies();
	%>
	<% if (!statusMessage.isEmpty()) { %>
		<p><strong><%= statusMessage %></strong></p>
	<% } %>
	
	<!-- gets input from user -->
	<div class="form-container">
		<form method="post" action="addMovie.jsp">
			<div class="form-group">
				<label for="title">Movie Title:</label>
				<input type="text" id="title" name="title" required>
			</div>
			<div class="form-group">
				<label for="director">Director:</label>
				<input type="text" id="director" name="director" required>
			</div>
			<div class="form-group">
				<label for="genre">Genre:</label>
				<input type="text" id="genre" name ="genre" required>
			</div>
			<div class="form-group">
				<label for="release_Year">Release Year:</label>
				<input type="number" id="releaseYear" name="releaseYear" min="1895" max="2050" required>
			</div>
			<div class="form-group">
				<label for="score">Score:</label>
				<input type="number" id="score" name="score" step="0.1" min="0" max="10" required>
			</div>
			<input type="submit" value="Add Movie">
		</form>
	</div>
	
	<hr>
	
	<!-- shows all entries in database -->
	<h2>Movie Database</h2>
	<p>Movies currently in the database</p>
	<table>
		<thead>
			<tr>
				<th>Movie ID (Primary Key)</th>
				<th>Movie Title</th>
				<th>Director</th>
				<th>Genre</th>
				<th>Release Year</th>
				<th>Score</th>
			</tr>
		</thead>
		<tbody>
			<!-- get the data for each field -->
			<% for (MovieBean m : allMovies) { %>
				<tr>
					<td><%= m.getMovieID() %></td>
					<td><%= m.getTitle() %></td>
					<td><%= m.getDirector() %></td>
					<td><%= m.getGenre() %></td>
					<td><%= m.getReleaseYear() %></td>
					<td><%= m.getScore() %></td>
				</tr>
			<% } %>
		</tbody>
	</table>
	
	<p><a href="index.jsp">Back to Index</a></p>
</body>
</html>