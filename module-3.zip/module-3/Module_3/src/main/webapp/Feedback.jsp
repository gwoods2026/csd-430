<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Survey Results</title>
<style>
	body {font-family: Arial, sans-serif; margin: 30px;}
	table {border-collapse: collapse; width: 60%; margin-top: 20px;}
	th, td {border: 1px solid #dddddd; text-align: left; padding: 12px;}
	th {background-color: #f2f2f2;}
</style>
</head>
<body>
	<%
		//Gets the data from the survey
		String name = request.getParameter("customerName");
		String date = request.getParameter("visitDate");
		String meal = request.getParameter("mealType");
		String foodRating = request.getParameter("foodRating");
		String serviceRating = request.getParameter("serviceRating");
		
		if (name == null) name = "No data";
		if (date == null) date = "No data";
		if (meal == null) meal = "No data";
		if (foodRating == null) foodRating = "No data";
		if (serviceRating == null) serviceRating = "No data";
	%>
	
	<!-- Setting up the variables -->
	<h2>Customer Feedback Report</h2>
	<table>
		<thead>
			<tr>
				<th>Field Description</th>
				<th>Record Value</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>Customer Name</td>
				<td><%= name %></td>
			</tr>
			<tr>
				<td>Date of Visit</td>
				<td><%= date %></td>
			</tr>
			<tr>
				<td>Meal</td>
				<td><%= meal %></td>
			</tr>
			<tr>
				<td>Food Rating</td>
				<td><%= foodRating %></td>
			</tr>
			<tr>
				<td>Service Rating</td>
				<td><%= serviceRating %></td>
			</tr>
		</tbody>
	</table>
	
	<p><a href="Form.html">Change your submission</a>
</body>
</html>