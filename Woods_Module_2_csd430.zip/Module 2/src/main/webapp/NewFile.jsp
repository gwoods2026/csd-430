<!-- Garrett Woods Module 2 -->

<%@ page language="java" contentType="text/html; charset=UTF-8"
    pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Books I Enjoyed Reading</title>
	<link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>

	<%
		//Scriplet to set up info
		String[] title = {
				"The Dark Tower",
				"The Wheel of Time",
				"The Mistborne Triligy",
				"Project Hail Mary",
				"The Martian"
		};
	
		String[] author = {
				"Steven King",
				"Robert Jordan",
				"Brandon Sanderson",
				"Andy Weir",
				"Andy Weir"
				
		};
		
		String[] genre = {
				"Sci-Fi, Western, Fantasy",
				"Fantasy",
				"Fantasy",
				"Sci-Fi",
				"Sci-Fi"
		};
		
		String[] publishYear = {
				"1982-2012",
				"1990-2013",
				"2006-2008",
				"2021",
				"2011"				
		};
		
		String[] summary = {
				"The Dark Tower series follows The Gunslinger and his team as they travel the world to find the Dark Tower",
				"A young group of friends gain powers and end up fighting evil to save the world",
				"A ragtag group of thevies and criminals take down the governmen and instill their own",
				"The earth is dying and we send a team to deep space to find out why",
				"A mission on Mars goes wrong and a signle astronaught is left on the surface"
		};
	%>
	
	<div>
			<h1>Book Details</h1>
		<!-- Creates the table -->
		<table>
			<thead>
				<tr>
					<th>Title</th>
					<th>Author</th>
					<th>Genre</th>
					<th>Year Published</th>
					<th>Short Summary</th>
				</tr>
			</thead>
			<tbody>
				<%
					//loop to populate the fileds of the table
					for (int i = 0; i < title.length; i++) {
				%>
					<tr>
						<td><%= title[i] %></td>
						<td><%= author[i] %></td>
						<td><%= genre[i] %></td>
						<td><%= publishYear[i] %></td>
						<td><%= summary[i] %></td>
				</tr>

			<%
				}
			%>

			</tbody>
		</table>
	</div>
</body>
</html>